#!/bin/sh

#  Customization instructions:
#
#  1) Make a copy of this file in your local project directory and name
#  it flash-local.sh so it will not be overwritten by a SwiftX update.
#
#  2) Carefully edit the command line below that invokes avrdude with
#  the correct parameters for your ISP programmer.  The sample here is
#  for an AVRISP2-compatible programmer that appears as port /dev/ttyACM1.


if [ $# -ne 2 ]; then
    echo "Usage: $0 fuse-high-byte fuse-low-byte" >&2
    exit 1
fi

avrdude -c avrisp2 -P /dev/ttyACM1 -p m328p -y -U flash:w:target.hex -u -U hfuse:w:0x$1:m -U lfuse:w:0x$2:m
